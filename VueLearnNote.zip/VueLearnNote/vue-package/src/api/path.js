const base = {
    baseUrl:"http://iwenwiki.com",
    chengpin:"/api/blueberrypai/getChengpinDetails.php"

    //日后所有的路径都放在这里面
}

export default base;