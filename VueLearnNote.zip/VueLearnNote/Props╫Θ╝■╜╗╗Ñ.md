# Props组件交互

前言：组件与组件之间是需要交互的

1：Prop是你可以在组件上自定义的属性。

prop可以将数据从父组件传递到子组件(引用子组件的就是父组件)

```vue
App.vue中假设数据：
data() {
    return {
      title:"标题1"
    }
  }
  <!-- :title把属性变动态 -->
  <MyComp :title="title"/>
MyComp.vue
<p>{{title}}</p>
props :{
    title:{
        type:String,
        default:"123"//默认值
    }
}此时显示标题1

如果是
<MyComp title="title"/>
左边的title就是静态，那么左title就完全等于右边你输入的文本值而不是data里面的title

如果是右边是数字
 <MyComp :title="123412"/>
 则最后结果显示数字
 
 如果是右边是带有字符
 <MyComp :title="title123412"/>
 则最后结果显示默认值 default:"123"//默认值

```

2.prop传递参数没有类型限制

例子：返回数组

```vue
在App.vue
<MyComp :title="title" :names="names"/>
data() {
    return {
      title:"标题1",
      names:["asd","asdffff","454y5h"]
    }

在MyComp.vue
<ul>
  <li v-for="(item,index) in names" :key="index">{{item}}</li>
</ul>
names:{
        type:Array,
        //数组和对象必须使用函数返回(工厂模式)
        default:function(){
            return [];
        }
    }
```
