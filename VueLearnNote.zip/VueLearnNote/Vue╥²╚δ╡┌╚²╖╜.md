# Vue引入第三方

`Swiper`轮播图插件

> **官方文档：**[**https://swiperjs.com/vue**](https://swiperjs.com/vue "https://swiperjs.com/vue")**安装指定版本:npm install --save swiper\@8.1.6**

> [**Swiper中文网**](https://www.swiper.com.cn/ "Swiper中文网")

模板的搜索

> 1.在github.com中搜索vue-swiper
> 网址：[https://github.com/search?q=vue-swiper](https://github.com/search?q=vue-swiper "https://github.com/search?q=vue-swiper")
> 选择搜索量高的

> 2.（Vue2）在v2.cn.vuejs.org中选择资源列表-Awesome Vue
> 网址：[https://github.com/vuejs/awesome-vue](https://github.com/vuejs/awesome-vue "https://github.com/vuejs/awesome-vue")
> 往下拉看到Components\&Libraries里面选择

1.基础实现

安装后引入：

```vue
  // Import Swiper Vue.js components
  import { Swiper, SwiperSlide } from 'swiper/vue';

  // Import Swiper styles
  import 'swiper/css';
```

组件注入：

```vue
  components:{
    Swiper,
    SwiperSlide,
  }
```

组件使用：

```vue
<Swiper>
      <!-- 制作轮播图 -->
      <SwiperSlide>
        <img src="../assets/logo.png" alt="">
      </SwiperSlide>
      <SwiperSlide>
        <img src="../assets/logo.png" alt="">
      </SwiperSlide>
      <SwiperSlide>
        <img src="../assets/logo.png" alt="">
      </SwiperSlide>
    </Swiper>
```

指示器添加：

引入组件：

```vue
import {Pagination} from 'swiper';
import 'swiper/css/pagination';

data() {
    return {
      modules:[ Pagination ],
    }
  },

```

组件使用

```vue
 <!-- clickable:true是否可点击触发转换图片 -->
 <Swiper class="MySwiper" :modules="modules" :pagination="{ clickable:true }">
```

后面不变
