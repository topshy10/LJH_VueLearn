<template>
    <h3>单文件组件</h3>
</template>

<script>
//导出对象
export default {
name:"MyComponent"

}

</script>

<!-- scoped:该属性表示该样式只在该组件生效 -->
<style scoped>


</style>