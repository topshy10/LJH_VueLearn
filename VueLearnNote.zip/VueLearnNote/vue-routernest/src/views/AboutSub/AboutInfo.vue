<template>
    <h3>关于信息</h3>
</template>